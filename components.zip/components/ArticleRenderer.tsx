"use client"

import { useEffect, useState } from "react"

// ─── Types ────────────────────────────────────────────────────────────────────

interface ArticleRendererProps {
  content: string | null | undefined
  className?: string
}

// ─── Component ────────────────────────────────────────────────────────────────

export function ArticleRenderer({ content, className = "" }: ArticleRendererProps) {
  const [html, setHtml] = useState(content || "")

  useEffect(() => {
    setHtml(content || "")
  }, [content])

  if (!content) return null

  return (
    <div
      className={[
        // ── Base ──────────────────────────────────────────────────────────
        "prose prose-lg max-w-none",

        // ── Paragraf ──────────────────────────────────────────────────────
        "prose-p:text-foreground/90",
        "prose-p:leading-[1.85]",
        "prose-p:mb-5",

        // ── Headings ──────────────────────────────────────────────────────
        "prose-headings:text-foreground",
        "prose-headings:font-semibold",
        "prose-headings:tracking-tight",
        "prose-headings:scroll-mt-24",
        "prose-h1:text-3xl prose-h1:mt-10 prose-h1:mb-4",
        "prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4",
        "prose-h2:border-b prose-h2:border-border prose-h2:pb-3",
        "prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3",
        "prose-h4:text-lg prose-h4:mt-6 prose-h4:mb-2",

        // ── Links ─────────────────────────────────────────────────────────
        "prose-a:text-primary",
        "prose-a:no-underline",
        "hover:prose-a:underline",
        "prose-a:transition-colors",
        "prose-a:font-medium",

        // ── Bold & Italic ─────────────────────────────────────────────────
        "prose-strong:text-foreground prose-strong:font-semibold",
        "prose-em:text-foreground/80",

        // ── Lists ─────────────────────────────────────────────────────────
        "prose-ul:text-foreground/90 prose-ol:text-foreground/90",
        "prose-li:my-1.5 prose-li:leading-[1.7]",
        "[&_ul>li::marker]:text-primary/60",
        "[&_ol>li::marker]:text-primary/60",

        // ── Blockquote ───────────────────────────────────────────────────
        "prose-blockquote:border-l-2 prose-blockquote:border-l-primary",
        "prose-blockquote:bg-secondary/60",
        "prose-blockquote:rounded-r-lg",
        "prose-blockquote:py-1 prose-blockquote:pl-5 prose-blockquote:pr-4",
        "prose-blockquote:text-foreground/70",
        "prose-blockquote:not-italic",
        "[&_blockquote_p]:italic [&_blockquote_p]:my-2",

        // ── Code inline ──────────────────────────────────────────────────
        "prose-code:bg-secondary",
        "prose-code:text-primary",
        "prose-code:text-[0.875em]",
        "prose-code:rounded prose-code:px-1.5 prose-code:py-0.5",
        "prose-code:before:content-none prose-code:after:content-none",

        // ── Code block ───────────────────────────────────────────────────
        "prose-pre:bg-card",
        "prose-pre:border prose-pre:border-border",
        "prose-pre:rounded-xl",
        "prose-pre:text-sm prose-pre:overflow-x-auto",

        // ── Gambar ──────────────────────────────────────────────────────
        "prose-img:rounded-xl prose-img:w-full prose-img:my-8",

        // ── Tabel modern ────────────────────────────────────────────────
        "prose-table:w-full prose-table:border-collapse prose-table:my-6 prose-table:text-sm",
        "prose-th:border prose-th:border-border",
        "prose-th:bg-secondary/60",
        "prose-th:px-4 prose-th:py-2.5",
        "prose-th:text-left prose-th:font-semibold prose-th:text-foreground",
        "prose-td:border prose-td:border-border",
        "prose-td:px-4 prose-td:py-2.5",
        "prose-td:text-foreground/80 prose-td:align-top",
        "[&_tbody_tr:nth-child(even)]:bg-secondary/30",

        // ── HR ────────────────────────────────────────────────────────────
        "prose-hr:border-border prose-hr:my-10",

        // ── Figcaption ───────────────────────────────────────────────────
        "prose-figcaption:text-center prose-figcaption:text-xs",
        "prose-figcaption:text-muted-foreground prose-figcaption:italic",

        // ── Group Standings Block ────────────────────────────────────────
        "[&_.group-standings-block]:my-6",
        "[&_.gs-header]:flex [&_.gs-header]:items-center [&_.gs-header]:gap-2 [&_.gs-header]:px-4 [&_.gs-header]:py-3 [&_.gs-header]:border-b [&_.gs-header]:border-border [&_.gs-header]:bg-secondary/20",
        "[&_.gs-header-icon]:text-lg",
        "[&_.gs-header-title]:flex-1 [&_.gs-header-title]:font-bold [&_.gs-header-title]:text-foreground [&_.gs-header-title]:text-sm",
        "[&_.gs-header-sub]:text-xs [&_.gs-header-sub]:text-muted-foreground",
        "[&_.gs-table-wrap]:overflow-x-auto",
        "[&_.gs-table]:w-full [&_.gs-table]:border-collapse [&_.gs-table]:text-xs [&_.gs-table]:m-0",
        "[&_.gs-thead-row]:border-b [&_.gs-thead-row]:border-border",
        "[&_.gs-th]:px-2 [&_.gs-th]:py-2.5 [&_.gs-th]:text-[10px] [&_.gs-th]:font-bold [&_.gs-th]:uppercase [&_.gs-th]:tracking-wider [&_.gs-th]:text-muted-foreground",
        "[&_.gs-th-rank]:text-left [&_.gs-th-rank]:pl-3",
        "[&_.gs-th-team]:text-left",
        "[&_.gs-th-num]:text-center",
        "[&_.gs-th-pts]:text-center [&_.gs-th-pts]:text-primary",
        "[&_.gs-th-form]:text-center",
        "[&_.gs-row]:border-b [&_.gs-row]:border-border/40 [&_.gs-row]:transition-colors hover:[&_.gs-row]:bg-secondary/30",
        "[&_.gs-td]:px-2 [&_.gs-td]:py-2",
        "[&_.gs-td-rank]:pl-3",
        "[&_.gs-td-num]:text-center [&_.gs-td-num]:text-muted-foreground",
        "[&_.gs-td-pts]:text-center [&_.gs-td-pts]:font-bold [&_.gs-td-pts]:text-foreground",
        "[&_.gs-td-form]:text-center",
        "[&_.gs-td-team]:min-w-[130px]",
        "[&_.gs-rank]:inline-flex [&_.gs-rank]:h-5 [&_.gs-rank]:w-5 [&_.gs-rank]:items-center [&_.gs-rank]:justify-center [&_.gs-rank]:rounded [&_.gs-rank]:text-[10px] [&_.gs-rank]:font-bold",
        "[&_.gs-rank-qualify]:bg-primary/15 [&_.gs-rank-qualify]:text-primary [&_.gs-rank-qualify]:border-l-2 [&_.gs-rank-qualify]:border-l-primary",
        "[&_.gs-rank-candidate]:bg-yellow-500/15 [&_.gs-rank-candidate]:text-yellow-500",
        "[&_.gs-rank-out]:text-muted-foreground",
        "[&_.gs-flag]:inline-flex [&_.gs-flag]:items-center [&_.gs-flag]:justify-center [&_.gs-flag]:rounded [&_.gs-flag]:bg-secondary [&_.gs-flag]:px-1 [&_.gs-flag]:text-[10px] [&_.gs-flag]:font-bold [&_.gs-flag]:text-muted-foreground [&_.gs-flag]:mr-1.5 [&_.gs-flag]:shrink-0",
        "[&_.gs-team-name]:text-sm [&_.gs-team-name]:font-medium [&_.gs-team-name]:text-foreground",
        "[&_.gs-form]:flex [&_.gs-form]:gap-0.5 [&_.gs-form]:justify-center",
        "[&_.gs-form-badge]:inline-flex [&_.gs-form-badge]:h-4 [&_.gs-form-badge]:w-4 [&_.gs-form-badge]:items-center [&_.gs-form-badge]:justify-center [&_.gs-form-badge]:rounded-full [&_.gs-form-badge]:text-[8px] [&_.gs-form-badge]:font-bold",
        "[&_.gs-form-w]:bg-green-500/20 [&_.gs-form-w]:text-green-400",
        "[&_.gs-form-d]:bg-yellow-500/20 [&_.gs-form-d]:text-yellow-400",
        "[&_.gs-form-l]:bg-destructive/20 [&_.gs-form-l]:text-destructive",
        "[&_.gs-legend]:flex [&_.gs-legend]:flex-wrap [&_.gs-legend]:gap-4 [&_.gs-legend]:px-3 [&_.gs-legend]:py-2 [&_.gs-legend]:border-t [&_.gs-legend]:border-border/40",
        "[&_.gs-legend-item]:text-[10px] [&_.gs-legend-item]:text-muted-foreground",
        "[&_.gs-legend-qualify]:text-primary",
        "[&_.gs-legend-candidate]:text-yellow-500",

        className,
      ]
        .filter(Boolean)
        .join(" ")}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  )
}

export default ArticleRenderer
